import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { MenubarComponent } from './menubar/menubar.component';
import { MaterialModule } from '../material/material.module';
import { DietplanComponent } from './dietplan/dietplan.component';
import { CreateComponent } from './create/create.component';
import { HomeComponent } from './home/home.component';
import { ForumComponent } from './forum/forum.component';
import { ProductComponent } from './home/product/product.component';
import { ProductdetailsComponent } from './home/productdetails/productdetails.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TypefilterPipe } from '../pipes/typefilter.pipe';
import { RouterModule } from '@angular/router';
import { DiettypeComponent } from './dietplan/diettype/diettype.component';
import { DietdetailsComponent } from './dietplan/dietdetails/dietdetails.component';

@NgModule({
  declarations: [
    MenubarComponent,
    HomeComponent,
    DietplanComponent,
    CreateComponent,
    ForumComponent,
    ProductComponent,
    ProductdetailsComponent,
    TypefilterPipe,
    DiettypeComponent,
    DietdetailsComponent,
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    MaterialModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule
  ],
  exports:[
    HomeComponent,
    MenubarComponent,
    
  ]
})
export class UserModule { }
