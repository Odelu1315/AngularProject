import { TypefilterPipe } from './typefilter.pipe';

describe('TypefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TypefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
